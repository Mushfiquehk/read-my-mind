# read-my-mind
Spotify API consumer using Flask
